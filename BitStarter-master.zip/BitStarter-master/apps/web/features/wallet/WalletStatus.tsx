"use client";

import { Check, ChevronDown, LogOut, Wallet } from "lucide-react";
import { useEffect, useState } from "react";
import {
  connectWallet,
  clearStoredWalletSession,
  defaultWalletProviderId,
  getWalletProvider,
  readStoredWalletSession,
  writeStoredWalletSession,
  walletProviders,
  type WalletProviderId,
  type WalletSession
} from "@/lib/stellar/wallet";

const providerStorageKey = "bitstarter.walletProvider";
const providerIds = walletProviders.map((provider) => provider.id);

function isWalletProviderId(value: string | null): value is WalletProviderId {
  return providerIds.includes(value as WalletProviderId);
}

export function WalletStatus() {
  const [session, setSession] = useState<WalletSession | null>(null);
  const [providerId, setProviderId] = useState<WalletProviderId>(defaultWalletProviderId);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const storedProviderId = window.localStorage.getItem(providerStorageKey);
    if (isWalletProviderId(storedProviderId)) {
      setProviderId(storedProviderId);
    }
    setSession(readStoredWalletSession());
  }, []);

  async function handleConnect(nextProviderId = providerId) {
    setLoading(true);
    setError("");
    try {
      const nextSession = await connectWallet(nextProviderId);
      setSession(nextSession);
      setProviderId(nextProviderId);
      window.localStorage.setItem(providerStorageKey, nextProviderId);
      writeStoredWalletSession(nextSession);
      setOpen(false);
    } catch (err) {
      setSession(null);
      clearStoredWalletSession();
      setError(err instanceof Error ? err.message : "Wallet connection failed.");
    } finally {
      setLoading(false);
    }
  }

  function handleSelectProvider(nextProviderId: WalletProviderId) {
    setProviderId(nextProviderId);
    window.localStorage.setItem(providerStorageKey, nextProviderId);
    setSession(null);
    clearStoredWalletSession();
    setError("");
  }

  function handleDisconnect() {
    setSession(null);
    clearStoredWalletSession();
    setError("");
    setOpen(false);
  }

  const provider = getWalletProvider(providerId);
  const buttonText = session?.connected
    ? `${session.publicKey.slice(0, 6)}...${session.publicKey.slice(-4)}`
    : loading
      ? "Connecting..."
      : provider.name;

  return (
    <div className="relative">
      <div className="flex overflow-hidden rounded-md border border-line bg-paper">
        <button
          type="button"
          onClick={() => session?.connected ? setOpen((current) => !current) : handleConnect()}
          disabled={loading}
          className="inline-flex min-h-10 items-center gap-2 px-3 text-sm font-medium disabled:opacity-60"
          title={session?.connected ? "Wallet connected" : `Connect ${provider.name}`}
        >
          <Wallet size={16} aria-hidden="true" />
          <span>{buttonText}</span>
        </button>
        <button
          type="button"
          onClick={() => setOpen((current) => !current)}
          className="inline-flex min-h-10 w-9 items-center justify-center border-l border-line"
          title="Choose wallet provider"
          aria-label="Choose wallet provider"
        >
          <ChevronDown size={16} aria-hidden="true" />
        </button>
      </div>

      {open ? (
        <div className="absolute right-0 z-20 mt-2 w-72 rounded-md border border-line bg-paper p-2 text-sm shadow-[6px_6px_0_#d9d4c9]">
          <div className="px-2 py-2 text-xs font-semibold uppercase text-slate-500">Wallet provider</div>
          <div className="space-y-1">
            {walletProviders.map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => handleSelectProvider(option.id)}
                className="flex w-full items-start gap-3 rounded-md px-2 py-2 text-left hover:bg-white"
              >
                <span className="mt-0.5 flex h-4 w-4 items-center justify-center">
                  {providerId === option.id ? <Check size={16} className="text-accent" aria-hidden="true" /> : null}
                </span>
                <span>
                  <span className="block font-medium">{option.name}</span>
                  <span className="block text-xs leading-5 text-slate-500">{option.description}</span>
                </span>
              </button>
            ))}
          </div>
          <div className="mt-2 border-t border-line pt-2">
            <button
              type="button"
              onClick={() => handleConnect()}
              disabled={loading}
              className="w-full rounded-md bg-ink px-3 py-2 text-left text-sm font-semibold text-white disabled:opacity-60"
            >
              {loading ? "Connecting..." : `Connect ${provider.name}`}
            </button>
            {session?.connected ? (
              <button
                type="button"
                onClick={handleDisconnect}
                className="mt-2 inline-flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm text-rose-700 hover:bg-rose-50"
              >
                <LogOut size={15} aria-hidden="true" />
                Disconnect
              </button>
            ) : null}
          </div>
          {error ? <p role="alert" className="mt-2 rounded-md bg-rose-50 p-2 text-xs text-rose-700">{error}</p> : null}
        </div>
      ) : null}
    </div>
  );
}
